package com.example.readingapplication;

import androidx.annotation.NonNull;
import androidx.annotation.StringRes;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private DrawerLayout draw;
    RecyclerViewAdapter recyclerViewAdapter;
    RecyclerView recyclerView;
    ArrayList<DataBuku> dataItems;

    static String jd1 = "Her World";
    static String jd2 = "Kita";
    static String jd3 = "Kita Bicarakan Tentang Luka";
    static String jd4 = "Antariksa";
    static String jd5 = "97Line";
    static String jd6 = "Rosie";
    static String jd7 = "Dinding";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        dataItems = new ArrayList<>();
        recyclerViewAdapter = new RecyclerViewAdapter(dataItems, this);

        dataItems.add(new DataBuku(R.drawable.cv1, jd1, "Rosemunk", "20 Oktober 2021"));
        dataItems.add(new DataBuku(R.drawable.cv2, jd2, "Markohun", "12 September 2019"));
        dataItems.add(new DataBuku(R.drawable.cv3, jd3, "Farahqueen", "20 Maret 2019"));
        dataItems.add(new DataBuku(R.drawable.cv5, jd4, "Lala", "14 Januari 2016"));
        dataItems.add(new DataBuku(R.drawable.cv6, jd5, "Xmun", "18 Juni 2020"));
        dataItems.add(new DataBuku(R.drawable.cv7, jd6, "Jeprix", "14 Mei 2019"));
        dataItems.add(new DataBuku(R.drawable.cv8, jd7, "Bingkasa", "25 April 2015"));

        recyclerView.setAdapter(recyclerViewAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        draw = findViewById(R.id.drawer_layout);
        final ActionBarDrawerToggle t = new ActionBarDrawerToggle(this, draw,
                R.string.open,
                R.string.close);

        draw.addDrawerListener(t);
        t.syncState();

        NavigationView navigationview = findViewById(R.id.nav_view);
        navigationview.setItemIconTintList(null);

        navigationview.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                int id = item.getItemId();
                switch(id) {
                    case R.id.nav_home:
                        Toast.makeText(MainActivity.this,
                                "Menu Beranda di klik", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_search:
                        Toast.makeText(MainActivity.this,
                                "Menu Pencarian di klik", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_library:
                        Toast.makeText(MainActivity.this,
                                "Menu Perpustakaan di klik", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_make:
                        Toast.makeText(MainActivity.this,
                                "Menu Buat di klik", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_profile:
                        Toast.makeText(MainActivity.this,
                                "Menu Profile di klik", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_notification:
                        Toast.makeText(MainActivity.this,
                                "Menu Notifikasi di klik", Toast.LENGTH_SHORT).show();
                        break;
                    case R.id.nav_setting:
                        Toast.makeText(MainActivity.this,
                                "Menu Pengaturan di klik", Toast.LENGTH_SHORT).show();
                        break;
                }
                return true;
            }
        });
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            openDrawer();
            if (item.getItemId() == android.R.id.home) {
                if ((draw) != null && (draw.isDrawerOpen(GravityCompat.START)))
                    closeDrawer();
            }
        }
        return true;
    }

    @SuppressWarnings("deprecation")
    private void closeDrawer() {
        draw.setDrawerListener(null);
        draw.closeDrawers();
    }
    @SuppressWarnings("deprecation")
    private void openDrawer() {
        draw.setDrawerListener(null);
        draw.openDrawer(GravityCompat.START);
    }
}